package model;

import java.sql.*;
import java.util.*;

public class DataBean {
    // Database connection info
    private String dbUrl = "jdbc:mysql://localhost:3306/csd430";
    private String dbUser = "student1";
    private String dbPass = "pass";

    // Connect to MySQL
    public Connection connect() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }

    // ✅ Get all movie records from database
    public List<Movie> getAllMovies() {
        List<Movie> movies = new ArrayList<>();
        String sql = "SELECT * FROM amit_movies_data";

        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Movie movie = new Movie(
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getString("genre"),
                    rs.getString("director"),
                    rs.getInt("year"),
                    rs.getFloat("rating")
                );
                movies.add(movie);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return movies;
    }

    // ✅ Delete movie by ID
    public void deleteMovieById(int id) {
        String sql = "DELETE FROM amit_movies_data WHERE id = ?";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
