package model;

public class Movie {
    private int id;
    private String title;
    private String genre;
    private String director;
    private int year;
    private float rating;

    public Movie(int id, String title, String genre, String director, int year, float rating) {
        this.id = id;
        this.title = title;
        this.genre = genre;
        this.director = director;
        this.year = year;
        this.rating = rating;
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getGenre() { return genre; }
    public String getDirector() { return director; }
    public int getYear() { return year; }
    public float getRating() { return rating; }

    public void setId(int id) { this.id = id; }
    public void setTitle(String title) { this.title = title; }
    public void setGenre(String genre) { this.genre = genre; }
    public void setDirector(String director) { this.director = director; }
    public void setYear(int year) { this.year = year; }
    public void setRating(float rating) { this.rating = rating; }
}
